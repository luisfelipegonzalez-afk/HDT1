# Sin valor por defecto: siempre hay que escribir la ciudad
def crear_perfil(nombre, edad, ciudad):
    return f"{nombre}, {edad} años, de {ciudad}"

print(crear_perfil("Ana", 20, "Guatemala"))
print(crear_perfil("Luis", 22, "Guatemala"))
print(crear_perfil("María", 19, "Guatemala"))  # Repetitivo...

# Solución: valor por defecto
def crear_perfil(nombre, edad, ciudad="Guatemala"):
    return f"{nombre}, {edad} años, de {ciudad}"

print(crear_perfil("Ana", 20))              # usa "Guatemala"
print(crear_perfil("Carlos", 21, "Xela"))   # usa "Xela"

def saludar(nombre, saludo="Hola", despedida=False):
    mensaje = f"{saludo}, {nombre}!"
    if despedida:
        mensaje += f"Hasta luego {nombre}"
        pass
    return mensaje

# Prueba estas llamadas:
print(saludar("Ana"))
print(saludar("Luis", saludo="Buenos días"))
print(saludar("María", despedida=True))
print(saludar(saludo="Hey", nombre="Carlos"))

# *args captura todos los argumentos posicionales en una TUPLA
def sumar_todos(*numeros):
    print(f"Recibí: {numeros}")  # Es una tupla
    print(f"Tipo: {type(numeros)}")
    return sum(numeros)

print(sumar_todos(1, 2, 3))          # Recibí: (1, 2, 3) -> 6
print(sumar_todos(10, 20, 30, 40))   # Recibí: (10, 20, 30, 40) -> 100
print(sumar_todos(5))                # Recibí: (5,) -> 5

def funcion(normal, defecto="valor", defecto2="valor2", *args, **kwargs):
    print(f"normal: {normal}")
    print(f"defecto: {defecto}")
    print(f"args: {args}")
    print(f"kwargs: {kwargs}")

funcion("a", "b", "c", "d", "e", x=1, y=2, z=3)