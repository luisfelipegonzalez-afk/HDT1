"""
def funcion(normal, defecto="valor", *args, **kwargs):
    print(f"normal: {normal}")
    print(f"defecto: {defecto}")
    print(f"args: {args}")
    print(f"kwargs: {kwargs}")

funcion("a", "b", "c", "d", x=1, y=2)
"""  
#cuales son los valores *kwargs en la linea 7
#1,2
#cuales son los valores normlaes en la linea 7
#a

#cuales son los valores por defecto en la linea 7
#b

def calcular_subtotal(precios):
    print(precios)
    suma_total = sum(precios)
    print(suma_total)
    return suma_total
    # ¿Qué va aquí? Retorna la suma de precios
   

def aplicar_descuento(subtotal, porcentaje=0):
    # ¿Qué va aquí? Resta el porcentaje al subtotal
    descuento = subtotal * porcentaje
    print(descuento)
    return subtotal - descuento



def calcular_iva(monto, tasa=0.12):
    # ¿Qué va aquí? Retorna el IVA
    print(monto)
    iva = monto * tasa
    return iva

def generar_factura(precios, descuento=0):
    sub = calcular_subtotal(precios)
    sub_desc = aplicar_descuento(sub, descuento)
    iva = calcular_iva(sub_desc)
    total = sub_desc + iva
    print(f"Subtotal: Q{sub:.2f} | IVA: Q{iva:.2f}")
    print(f"Descuento: {descuento*100}% | Total: Q{total:.2f}")

generar_factura([25.00, 15.50, 8.99], descuento=0.10)

# Forma 1: importar módulo completo
import math
print(math.sqrt(16))    # 4.0
print(math.pi)          # 3.14159...

# Forma 2: importar funciones específicas
from math import sqrt, pi
print(sqrt(16))         # 4.0 (sin prefijo math.)

# Forma 3: importar con alias
import random as rnd
print(rnd.randint(1, 10))